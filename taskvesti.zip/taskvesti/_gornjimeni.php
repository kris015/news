<div class="row mb-3">
    <div class="col-12" style="background-color: lightblue;">
        <?php
        echo "<div class='link'><a style='color:black' href='index.php'>Početna</a></div>";
            
        $upit="SELECT * FROM kategorije";
        $rez=$db->query($upit);
        while($red=$db->fetch_assoc($rez))
            echo "<div class='link'><a style='color:black' href='index.php?kategorija={$red['id']}'>{$red['naziv']}</a></div>";
        
        if(login()){
            echo "<div class='link'><a style='color:green' href='odjava.php'>{$_SESSION['podaci']}</a></div>";
        }else
            echo "<div class='link'><a style='color:red' href='prijava.php'>Prijavite se</a></div>";
        ?>
    </div>
</div>