<!--FUTER-->
<!--<div class="row">
    <center>
    <div class="col-12">
        IT-Akademija G1 &copy; 2023
    </div>
    </center>
</div>-->
<div class="row mb-3">
    <center>
        <div class="col-12" style="background-color: red">
            Vesti NEWS &copy; 2023
        </div>
    </center>
</div>