<!--HEADER-->
<div class="row">
    <div class="col-12">
        <img src="images/header.jpg" width="100%" height="400px" alt="">
    </div>
</div>