<?php
session_start();
require_once("_obavezni.php");
//$db=konekcija();
$db=new Baza();
if(!$db->connect()) exit();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title>Document</title>
    <style>
        .slikeMale{
            display:inline-block;
            margin:5px;
            border: 1px solid black;
        }
    </style>
</head>
<body>
    <div class="container">
        <!--HEADER-->
        <?php require_once("_header.php");?>
        <!--GORNJI MENI-->
        <?php require_once("_gornjimeni.php");?>
        
        <div class="row">
            <!--GLAVNI SADRŽAJ-->
            <div class="col-9">
            <?php
            
            //statistika($db);
            
            if(isset($_GET['id'])){
                $upit="SELECT * FROM pogledproizvodi WHERE obrisan=0 AND id={$_GET['id']}";
                $rez=$db->query($upit);
                if($db->error()==""){
                    if($db->num_rows($rez)>0){
                        echo "Broj odgovora iz baze: ".$db->num_rows($rez)."<hr>";
                        while($red=$db->fetch_assoc($rez)){
                            echo "<div class='vest'>";
                            echo "<div><a href='index.php?kategorija={$red['kategorija']}'>{$red['naziv']}</a></div>";
                            echo "<div><h3>{$red['naslov']}</h3></div>";
                            echo "<p>".nl2br($red['tekst'])."</p>";
                            echo "<div><u><a href='index.php?autor={$red['autor']}'>{$red['ime']} {$red['prezime']}</a></u> | <i>{$red['vremeK']}</i></div>";
                            echo "</div><hr>";

                        }
                    }
                    else
                        echo Poruka::greska("Proizvod koju tražite nije dostupan ili je obrisan");
                }
                else
                    echo "Došlo je do greške prilikom izvršavanja upita<br>".$db->error();
            }
            else
                echo Poruka::greska("Proizvod koju tražite nije dostupan");
            ?>
            </div>
            <!--DESNI MENI-->
            <?php require_once("_desnimeni.php");?>
        </div>

        <!--FUTER-->
        <?php require_once("_footer.php");?>

    </div>
</body>
</html>