<?php
session_start();
require_once("_obavezni.php");
//Provera da li je korisnik ulogovan
if(!login()){
    echo "<h1>Morate biti prijavljeni!!!</h1><br><a href='prijava.php'>Prijavite se</a></div>";
    exit();
}
//Provera da li je korisnik ulogovan kao Administrator
if($_SESSION['status']!="Administrator"){
    echo "<h1>Morate biti prijavljeni kao Administrator!!!</h1><br><a href='prijava.php'>Prijavite se</a></div>";
    exit();
}

//$db=konekcija();
$db=new Baza();
if(!$db->connect()) exit();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title>Document</title>
</head>
<body>
    <div class="container">
        <!--HEADER-->
        <?php require_once("_header.php");?>
        <!--GORNJI MENI-->
        <?php require_once("_gornjimeni.php");?>
        
        <div class="row">


           
        <form action="dodajProizvod.php" method="POST">
        <input type="text" name="naslov" placeholder="Unesite naslov"> <br> <br>
        <input type="text" name="tekst" placeholder="Unesite tekst"> <br><br>
        <input type="text" name="kategorija" placeholder="Kategorija broj:"> <br><br>
        <input type="text" name="autor" placeholder="Autor broj:"> <br><br>
        <button>Sacuvaj</button>
    </form>
    <br>

    <?php
     
        if(isset($_POST['naslov']) and isset($_POST['tekst']) and isset($_POST['kategorija']) and isset($_POST['autor'])){
            $naslov=$_POST['naslov'];
            $tekst=$_POST['tekst'];
            $kategorija=$_POST['kategorija'];
            $autor=$_POST['autor'];

            if($naslov!="" and $tekst!="" and $kategorija!="" and $autor!=""){
                $upit="INSERT INTO proizvodi (naslov, tekst, kategorija, autor) VALUES ('{$naslov}', '{$tekst}', '{$kategorija}', '{$autor}')";        
        }
                    $db->query($upit);
                            if($db->error()==""){
                                echo Poruka::uspeh("Uspešno snimljeni podaci u bazu");
                                Log::upisi("logovi/".date("Y-m-d")."_korisnici.log", "Dodata vest: '{$naslov}'."); 
                                if(isset($_FILES['avatar']) and $_FILES['avatar']['name']!=""){
                                    $name=$db->insert_id().".jpg";
                                    if(@move_uploaded_file($_FILES['avatar']['tmp_name'], "avatars/".$name)) echo Poruka::uspeh("Uspešno prebačen avatar na server");
                                    else echo Poruka::greska("NEUSPEŠNO prebačen avatar na server!!!");
                                }
                            }
                            else
                                echo Poruka::greska("Greska prilikom upisa podataka u bazu!!<br>".$db->error());
        }
    ?>







            <!--DESNI MENI-->
            <?php require_once("_desnimeni.php");?>
        </div>

        <!--FUTER-->
        <?php require_once("_footer.php");?>

    </div>
</body>
</html>