-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 10, 2023 at 04:59 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.0.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `g1`
--

-- --------------------------------------------------------

--
-- Table structure for table `kategorije`
--

CREATE TABLE `kategorije` (
  `id` int(2) UNSIGNED NOT NULL,
  `naziv` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategorije`
--

INSERT INTO `kategorije` (`id`, `naziv`) VALUES
(1, 'Sport'),
(2, 'Zdravlje'),
(3, 'Putovanja'),
(4, 'Politika'),
(5, 'Život');

-- --------------------------------------------------------

--
-- Table structure for table `korisnici`
--

CREATE TABLE `korisnici` (
  `id` int(10) UNSIGNED NOT NULL,
  `ime` varchar(50) NOT NULL,
  `prezime` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `lozinka` varchar(256) NOT NULL,
  `status` enum('Administrator','Urednik','Korisnik') NOT NULL,
  `aktivan` int(11) NOT NULL DEFAULT 1,
  `vremeK` timestamp NOT NULL DEFAULT current_timestamp(),
  `vremeI` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `obrisan` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `korisnici`
--

INSERT INTO `korisnici` (`id`, `ime`, `prezime`, `email`, `lozinka`, `status`, `aktivan`, `vremeK`, `vremeI`, `obrisan`) VALUES
(1, 'Ivan', 'Ivanovic', 'ivan@gmail.com', 'ivan', 'Administrator', 1, '2022-12-26 19:25:14', '2023-02-09 01:40:38', 0),
(2, 'Pera', 'Perić', 'pperic@skola.com', 'pperic', 'Urednik', 1, '2022-12-26 19:25:14', '2023-01-12 15:47:01', 0),
(3, 'Nemanja', 'Tadic', 'nemanja@hotmail.com', 'nemanja', 'Korisnik', 1, '2022-12-26 15:47:39', '2023-02-09 01:42:58', 0),
(4, 'Srdjan ', 'Bantic', 'srdjan@gmail.com', 'srdjan', 'Korisnik', 1, '2023-01-12 18:32:25', '2023-02-09 01:42:52', 0),
(13, 'Stefan', 'Stefanovic', 'stefan@gmail.com', '12345', 'Urednik', 1, '2023-02-10 00:11:25', NULL, 0),
(14, 'Mirko', 'Mirkovic', 'mirko@gmail.com', '12345', 'Administrator', 1, '2023-02-10 00:13:58', NULL, 0);

-- --------------------------------------------------------

--
-- Stand-in structure for view `pogledproizvodi`
-- (See below for the actual view)
--
CREATE TABLE `pogledproizvodi` (
`id` int(10) unsigned
,`naslov` varchar(200)
,`tekst` text
,`kategorija` int(50)
,`autor` int(5)
,`vremeK` timestamp
,`vremeI` timestamp
,`obrisan` int(11)
,`ime` varchar(50)
,`prezime` varchar(100)
,`naziv` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `proizvodi`
--

CREATE TABLE `proizvodi` (
  `id` int(10) UNSIGNED NOT NULL,
  `naslov` varchar(200) NOT NULL,
  `tekst` text NOT NULL,
  `kategorija` int(50) NOT NULL,
  `autor` int(5) NOT NULL,
  `vremeK` timestamp NOT NULL DEFAULT current_timestamp(),
  `vremeI` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `obrisan` int(11) NOT NULL DEFAULT 0,
  `pogledan` int(5) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `proizvodi`
--

INSERT INTO `proizvodi` (`id`, `naslov`, `tekst`, `kategorija`, `autor`, `vremeK`, `vremeI`, `obrisan`, `pogledan`) VALUES
(1, 'Mitrović obrće Premijer ligu – dve asistencije, pa gol', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla a sodales sem. Mauris libero ipsum, varius sit amet nulla at, maximus scelerisque quam. Phasellus at diam laoreet, faucibus augue ac, aliquet massa. Etiam a metus non enim molestie ornare eu eu quam. Nam venenatis nunc mauris, vitae hendrerit metus posuere non. In condimentum sagittis diam quis semper. Duis efficitur lacinia ligula, vel aliquam diam pharetra eu. Nullam dolor risus, iaculis porta urna in, mattis venenatis purus. Nam in diam eu tellus porta luctus eu in lacus. Suspendisse viverra suscipit eros et tempor. Quisque tincidunt ullamcorper posuere. Mauris dictum molestie nisi, sit amet porttitor mauris iaculis nec.', 1, 1, '2022-12-04 17:09:15', '2023-01-12 17:35:34', 0, 0),
(2, 'Gordon izveo zakucavanje godine; Jokić: Bio sam otvoren', 'Ut tristique ante sed risus dictum, a cursus risus sodales. Nunc pharetra massa ac odio ullamcorper faucibus. In quam nisi, fermentum vitae augue id, venenatis porta lectus. Maecenas ac sagittis justo, at fringilla tellus. Quisque auctor ut lorem et sodales. Vivamus viverra ligula sed vestibulum efficitur. Maecenas commodo eu urna vel sagittis. Donec ac tempus ligula. Sed at luctus nisi, a iaculis velit. Sed eu gravida metus. Donec ac lacus id enim tincidunt lobortis. Duis commodo libero at pellentesque finibus. Nam imperdiet, tellus et ultrices venenatis, magna est posuere ante, vel dictum nulla massa vitae nisi. Sed ultricies felis sapien, sit amet scelerisque ante luctus nec. Phasellus sodales lorem diam, quis commodo turpis auctor et.', 2, 1, '2022-12-26 17:09:15', '2023-01-12 16:55:28', 0, 0),
(3, 'Postoji način da poboljšate kardiovaskularne sposobnosti, otkriven je pre 50 godina i to slučajno', 'Sed feugiat, mauris posuere imperdiet aliquam, tortor lacus tempus urna, et semper turpis dui eget odio. Mauris ut magna elit. Integer nec ultrices quam. Praesent vulputate orci justo, eget viverra est imperdiet ut. Ut eget porttitor sapien. Fusce varius nibh eget sem vehicula aliquam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque aliquam bibendum est, vitae varius ligula consectetur eu.', 3, 2, '2022-12-30 17:10:41', '2023-01-12 17:35:38', 0, 0),
(4, 'Lekar otkrio šta se dešava u organizmu ako san traje duže od 9 sati', 'Maecenas laoreet euismod faucibus. Morbi malesuada sit amet risus eget pellentesque. Nunc vel ante vitae urna convallis porttitor. Nunc est lorem, vulputate eu ultricies non, consequat non nisi. Sed eget blandit ex, ac iaculis massa. Phasellus hendrerit varius tellus ac feugiat. Donec orci ex, lobortis non laoreet non, ornare nec dui. Quisque convallis dignissim lacus id eleifend.', 3, 2, '2022-12-26 17:10:41', '2023-01-12 16:55:44', 0, 0),
(5, 'Svetski kuvari presudili; Objavljen spisak deset najboljih srpskih jela', 'Nullam efficitur, nibh nec luctus placerat, mauris magna faucibus arcu, in suscipit felis sem nec erat. Aliquam quis quam arcu. Aenean blandit imperdiet turpis, vitae ornare ligula laoreet nec. Nullam accumsan tortor vel suscipit fringilla. Sed dolor nibh, consequat quis convallis eget, imperdiet vel tortor. Nam imperdiet id augue quis dictum. Etiam suscipit et massa non gravida.', 4, 3, '2022-12-26 17:11:39', '2023-01-12 16:55:48', 0, 0),
(6, 'Mitrović obrće Premijer ligu OPET – tri asistencije, pa 2 gola', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla a sodales sem. Mauris libero ipsum, varius sit amet nulla at, maximus scelerisque quam. Phasellus at diam laoreet, faucibus augue ac, aliquet massa. Etiam a metus non enim molestie ornare eu eu quam. Nam venenatis nunc mauris, vitae hendrerit metus posuere non. In condimentum sagittis diam quis semper. Duis efficitur lacinia ligula, vel aliquam diam pharetra eu. Nullam dolor risus, iaculis porta urna in, mattis venenatis purus. Nam in diam eu tellus porta luctus eu in lacus. Suspendisse viverra suscipit eros et tempor. Quisque tincidunt ullamcorper posuere. Mauris dictum molestie nisi, sit amet porttitor mauris iaculis nec.', 1, 3, '2022-12-05 17:09:15', '2023-01-12 17:35:26', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `slikeproizvoda`
--

CREATE TABLE `slikeproizvoda` (
  `id` int(4) UNSIGNED NOT NULL,
  `idProizvoda` int(4) DEFAULT NULL,
  `imeSlike` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `slikeproizvoda`
--

INSERT INTO `slikeproizvoda` (`id`, `idProizvoda`, `imeSlike`) VALUES
(1, 16, '1675366088.5301_2-summer-beach-christopher-elwell-and-amanda-haselock.jpg'),
(2, 16, '1675366088.5317_1000_F_294032590_C4mXxgRWDO435yFE97ob0nviY4nEz0s1.jpg'),
(3, 16, '1675366088.5331_summer-beach-background-seashells-57302038.jpg');

-- --------------------------------------------------------

--
-- Structure for view `pogledproizvodi`
--
DROP TABLE IF EXISTS `pogledproizvodi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `pogledproizvodi`  AS SELECT `proizvodi`.`id` AS `id`, `proizvodi`.`naslov` AS `naslov`, `proizvodi`.`tekst` AS `tekst`, `proizvodi`.`kategorija` AS `kategorija`, `proizvodi`.`autor` AS `autor`, `proizvodi`.`vremeK` AS `vremeK`, `proizvodi`.`vremeI` AS `vremeI`, `proizvodi`.`obrisan` AS `obrisan`, `korisnici`.`ime` AS `ime`, `korisnici`.`prezime` AS `prezime`, `kategorije`.`naziv` AS `naziv` FROM ((`proizvodi` join `korisnici` on(`proizvodi`.`autor` = `korisnici`.`id`)) join `kategorije` on(`proizvodi`.`kategorija` = `kategorije`.`id`))  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kategorije`
--
ALTER TABLE `kategorije`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `korisnici`
--
ALTER TABLE `korisnici`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `proizvodi`
--
ALTER TABLE `proizvodi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slikeproizvoda`
--
ALTER TABLE `slikeproizvoda`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kategorije`
--
ALTER TABLE `kategorije`
  MODIFY `id` int(2) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `korisnici`
--
ALTER TABLE `korisnici`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `proizvodi`
--
ALTER TABLE `proizvodi`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `slikeproizvoda`
--
ALTER TABLE `slikeproizvoda`
  MODIFY `id` int(4) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
