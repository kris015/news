<?php
        $conn = new mysqli( "localhost", "root", "", "g1" );
        if($conn->connect_error){
            die("Neuspela konekcija na bazu: ".$conn->connect_error);
        }
           
        $db= mysqli_select_db( $conn, "proizvodi" );

        if(isset($_POST['id'])){
            $id=$_POST['id'];
            if($id!="0"){
                $upit="DELETE FROM proizvodi WHERE id={$id}";
                mysqli_query($conn, $upit);
                if(mysqli_error($conn)) echo "Greska! prilikom izvrsavanja upita <br>". mysqli_error($conn);
                else  echo "Uspesno obrisan podatak iz baze sa id={$id}!!!";
                
                
            
        }
    }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Brisanje</title>
</head>

<body>

    
 
    <h1>Brisanje podataka iz baze</h1>

    <a href="index.php">Prikaz vesti iz baze</a> <br><br>
    <a href="dodajProizvod.php">Unos novih podataka u bazu</a><br><br>


    <form action="obrisiVest.php" method="POST">
        <select name="id" id="id">
        <option value="0"> Izaberite podatak za brisanje</option>
        <?php
            $upit="SELECT * FROM proizvodi ORDER BY id DESC";
            $rez=mysqli_query($conn, $upit);
            while($red=mysqli_fetch_assoc($rez))
                    echo "<option value='{$red['id']}'>{$red['naslov']}</option>";
        ?>
        </select><br><br>

        <Button>Obrisite vest</button>
</form>
        
</body>
</html>