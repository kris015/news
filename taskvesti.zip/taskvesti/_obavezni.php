<?php
require_once("funkcije.php");
require_once("klase/classBaza.php");
require_once("klase/classPoruka.php");
require_once("klase/classLog.php");
?>