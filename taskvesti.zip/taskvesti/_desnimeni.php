<!--DESNI MENI-->
<div class="col-3">
    <?php
    if(login()){
        if($_SESSION['status']=="Administrator"){
            echo "<div class='okvir'>
                    <div class='naslovDesni'>ADMINISTRATOR</div>
                    <div>
                    <ul>
                        <li><a href='dodajKorisnika.php'>Dodaj korisnika</a></li>
                        
                        
                    </ul>
                    </div>
                </div>";
        }
    
        if($_SESSION['status']=="Administrator" or $_SESSION['status']=="Urednik"){
            echo "<div class='okvir'>
                    <div class='naslovDesni'>UREDNIK</div>
                    <div>
                    <ul>
                        <li><a href='dodajProizvod.php'>Dodaj proizvod</a></li>
                        <li><a href='obrisiVest.php'>Obriši vest</a></li>
                    </ul>
                    </div>
                </div>";
        }
        echo "<div class='okvir'>
                    <div class='naslovDesni'>KORISNIK</div>
                    <div>
                    <ul>
                        
                        
                        <li><a href='odjava.php'>Odjavite se</a></li>
                    </ul>
                    </div>
                </div><hr>";
    }
    

    ?>
    <div class="okvir">
        <div class="naslovDesni">Vremenska prognoza</div>
        <div>Lorem ipsum dolor sit amet consectetur adipisicing.</div>
    </div>

    <div class="okvir">
        <div class="naslovDesni">Kvalitet vazduha</div>
        <div>Lorem ipsum dolor sit amet.</div>
    </div>

    <div class="okvir">
        <div class="naslovDesni">Posetite nas</div>
        
    </div>
</div>